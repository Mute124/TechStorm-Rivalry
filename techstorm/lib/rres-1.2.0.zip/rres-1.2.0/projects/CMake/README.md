# rres CMake Definitions

This provides a CMake definition file for rres.

## Usage

``` sh
cd projects/CMake
mkdir build
cd build
cmake ..
make
```